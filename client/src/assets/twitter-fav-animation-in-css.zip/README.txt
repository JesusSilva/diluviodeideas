A Pen created at CodePen.io. You can find this one at https://codepen.io/spaceninja/pen/YpyPZX.

 A recreation of the Twitter fav animation in CSS

Based on http://codepen.io/chrismabry/pen/ZbjZEj