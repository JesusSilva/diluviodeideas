$('.heart').click(function () {
  $(this).toggleClass('active');
});